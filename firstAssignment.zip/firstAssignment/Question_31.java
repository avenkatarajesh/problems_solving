package firstAssignment;
// Program to Find the Roots of a Quadratic Equation

import java.util.Scanner;

public class Question_31 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter coefficient of  a : ");
		double a = scan.nextInt();
		
		System.out.println("Enter coefficient of  b : ");
		double b = scan.nextInt();
		
		System.out.println("Enter coefficient of  c : ");
		double c = scan.nextInt();
		
		double discriminant = b*b - (4*a*c) ;
		
		double root1=0 , root2=0 ;
		
		if( discriminant > 0 ) {
			double numeratorPart = Math.sqrt(discriminant);
			double numerator1 =  -b + numeratorPart;
			double numerator2 =  -b - numeratorPart;
			
			double denominator = 2*a;
			
			root1 = numerator1/denominator;
			root2 = numerator2/denominator;
			System.out.println("Root1  "+root1);
			System.out.println("Root2  "+root2);
			
		}else if ( discriminant == 0) {
			
			root1 = root2 = -( b/ 2*a );
			System.out.println("Root1  "+root1);
			System.out.println("Root2  "+root2);
			
		}else {
			
			double realPart = -(b / 2*a);
			double r = Math.abs(discriminant);
			double imagpart = Math.sqrt(r)/2*a;
			System.out.printf("root1 = %.4f + i%.4f \n",realPart,imagpart);
			System.out.printf("root1 = %.4f - i%.4f \n",realPart,imagpart);
			
		}
		
		
	}

}
