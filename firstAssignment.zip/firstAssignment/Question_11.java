package firstAssignment;
// Java Program to left rotate the elements of a multidimensional array.
public class Question_11 {
	
	public static void main(String[] args) {
		
		int[][] arr = {{1,2,3,4},
					   {5,6,7,8},
					   {9,10,11,12},
					   {13,14,15,16}
					   };
		
		int n = arr.length;
		
		for(int i = 0 ; i < n ; i++ ) {
			int temp = arr[i][0];
			int j = 0;
			for(j = 0 ; j < n-1 ; j++) {
				arr[i][j] = arr[i][j+1];
			}
			if(j == n-1) {
				arr[i][j] = temp;
			}
		}
		System.out.println("two - Dimensional");
		for(int[] l : arr) {
		for(int m : l) {
			System.out.print(m +" ");
		}
		System.out.println();
		}
		
	}

}
