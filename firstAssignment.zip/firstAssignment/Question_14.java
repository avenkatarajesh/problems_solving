package firstAssignment;
//Write a program to find the area of the rectangle
import java.util.Scanner;

public class Question_14 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the length : ");
		int length = scan.nextInt();
		System.out.println("Enter the width : ");
		int width = scan.nextInt();
		
		
		// area of rectangle is Length X Width
		System.out.println("Area is : " + length*width);
		
		
		
		
	}

}
