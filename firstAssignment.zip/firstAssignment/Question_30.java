package firstAssignment;

import java.util.Arrays;

// Program to Find the Largest Number Among Three Numbers

public class Question_30 {

	public static void main(String[] args) {
		
		int a = 40;
		int b = 20;
		int c = 30;
		
		int largest = a < b ? b : a ;
		    largest = largest < c ? c : largest;
		
		System.out.println(largest);
		
	}

}
